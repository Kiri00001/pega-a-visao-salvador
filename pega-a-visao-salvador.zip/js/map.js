const map = L.map('map').setView([-12.97, -38.51], 11);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; OpenStreetMap contributors',
}).addTo(map);

const faccaoCores = {
  'CV': '#d73027',
  'PCC': '#4575b4',
  'BDM': '#1a9850',
  'CP': '#fee08b',
  'Disputa': '#aaaaaa'
};

const alertaIcon = L.icon({
  iconUrl: 'icons/alert.png',
  iconSize: [24, 24],
  iconAnchor: [12, 12]
});

fetch('data/bairros.geojson')
  .then(res => res.json())
  .then(data => {
    L.geoJSON(data, {
      style: feature => ({
        color: '#333',
        weight: 1,
        fillOpacity: 0.7,
        fillColor: faccaoCores[feature.properties.faccao] || '#ccc'
      }),
      onEachFeature: (feature, layer) => {
        const nome = feature.properties.nome;
        const faccao = feature.properties.faccao;
        const risco = feature.properties.risco;
        layer.bindTooltip(`${nome} - ${faccao}`);
        if (risco === 'alto') {
          const marker = L.marker(layer.getBounds().getCenter(), { icon: alertaIcon }).addTo(map);
          marker.bindTooltip("Alto risco: mais de 90 homicídios por 100 mil habitantes");
        }
      }
    }).addTo(map);
  });
